import 'package:flutter/material.dart';

var profilePicture = 'assets/UserProfilePlaceholder.png';
var points = 100;
var username = 'UserName';
var email = 'Email@gmail.com';
