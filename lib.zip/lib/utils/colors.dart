import 'package:flutter/material.dart';

var primaryColor = Color.fromARGB(255, 248, 247, 255);
var secondaryColor = Color.fromARGB(255, 13, 71, 161);
var texthighlightColor = Color(0xFF717CE2);
var highlightColor = Color.fromARGB(255, 255, 228, 94);
var buttonhiglightColor = Color(0xFF717CE2);
var borderColor = Color.fromARGB(255, 204, 219, 253);
var highlighterColor = Color.fromARGB(255, 255, 99, 146);
var shadowColor = Color.fromARGB(255, 5, 42, 96);
