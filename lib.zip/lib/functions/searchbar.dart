import 'package:flutter/material.dart';
import 'package:flutter_uas_testing/utils/colors.dart';

Widget buildTextField(String hintText, IconData prefixIcon) {
  TextEditingController search = TextEditingController();
  return TextField(
    style: TextStyle(
      color: secondaryColor.withOpacity(0.8),
    ),
    controller: search,
    decoration: InputDecoration(
      filled: true,
      fillColor: primaryColor,
      contentPadding: const EdgeInsets.only(bottom: 5.0),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: buttonhiglightColor),
      ),
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: borderColor),
      ),
      hintText: hintText,
      hintStyle: TextStyle(
        fontSize: 16.0,
        color: secondaryColor.withOpacity(0.8),
      ),
      prefixIcon: Icon(
        prefixIcon,
        size: 20.0,
      ),
      prefixIconColor: secondaryColor.withOpacity(0.8),
    ),
  );
}
